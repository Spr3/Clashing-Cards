﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Collections;
using System.Threading;

//AI 


namespace Game
{

    public partial class Form1 : Form
    {

        Random rand = new Random();
        string[] cardsowned = new string[] { };
        string[] YourCards2 = new string[] { };
        string[] ThereCards2 = new string[] { };
        string[] ThereHand = new string[] { "0", "0", "0", "0", "0" };

        bool ISAITurn = false;
        int CardsPlayed = 0;
        string CardNumber = "0";
        bool playingcard = false;

        public void AI()
        {
            label1.Visible = true;
            label1.Text = "Pick a Card To Trow Away";
            while (ISAITurn)
            {
                int position = 0;
                string biggestnumber = ThereHand[rand.Next(1, ThereHand.Length)];
                if (biggestnumber == "Switch two" || biggestnumber == "Reset Your Deck" || biggestnumber == "Search")
                { }
                else
                {
                    if (Int32.Parse(biggestnumber) >= 1)
                    {
                        CardsPlayed++;
                        while (true)
                        {
                            int yournumber = rand.Next(1, ThereCards2.Length);
                            if (ThereCards2[yournumber] == "0")
                            { }
                            else
                            {
                                ThereHand[position] = yournumber.ToString();
                                ThereCards2[yournumber] = "0";
                                break;
                            }
                        }
                        int endboard = 1;
                        int Num = rand.Next(1, 8);
                        button35.Text = biggestnumber.ToString();
                        if (Num == 1)
                        {
                            string buttontext = A1.Text;
                            if (buttontext == "")
                            {
                                A1.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                A1.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                        else if (Num == 2)
                        {
                            string buttontext = button2.Text;
                            if (buttontext == "")
                            {
                                button2.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                button2.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                        else if (Num == 3)
                        {
                            string buttontext = button3.Text;
                            if (buttontext == "")
                            {
                                button3.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                button3.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                        else if (Num == 4)
                        {
                            string buttontext = button4.Text;
                            if (buttontext == "")
                            {
                                button4.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                button4.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                        else if (Num == 5)
                        {
                            string buttontext = button5.Text;
                            if (buttontext == "")
                            {
                                button5.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                button5.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                        else if (Num == 6)
                        {
                            string buttontext = button6.Text;
                            if (buttontext == "")
                            {
                                button6.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                button6.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                        else if (Num == 7)
                        {
                            string buttontext = button7.Text;
                            if (buttontext == "")
                            {
                                button7.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                button7.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                        else
                        {
                            string buttontext = button8.Text;
                            if (buttontext == "")
                            {
                                button8.Text = biggestnumber.ToString();
                            }
                            else
                            {
                                button8.Text = (Int32.Parse(buttontext) + Int32.Parse(biggestnumber)).ToString();
                            }
                            if (CardsPlayed >= endboard)
                            {
                                ISAITurn = false;
                            }
                        }
                    }
                }
            }
            label1.Visible = false;
            bool Board = false;
            bool everythingelse = true;
            UPButton.Visible = everythingelse;
            A1.Visible = Board;
            button1.Visible = Board;
            button2.Visible = Board;
            button3.Visible = Board;
            button4.Visible = Board;
            button5.Visible = Board;
            button6.Visible = Board;
            button7.Visible = Board;
            button8.Visible = Board;
            button9.Visible = Board;
            button10.Visible = Board;
            button11.Visible = Board;
            button12.Visible = Board;
            button13.Visible = Board;
            button14.Visible = Board;
            button15.Visible = Board;
            button16.Visible = Board;
            button17.Visible = Board;
            button18.Visible = Board;
            button19.Visible = Board;
            button20.Visible = Board;
            button21.Visible = Board;
            button22.Visible = Board;
            button23.Visible = Board;
            button24.Visible = Board;
            button25.Visible = Board;
            button26.Visible = Board;
            button27.Visible = Board;
            button28.Visible = Board;
            button29.Visible = Board;
            button30.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button41.Visible = Board;
            button42.Visible = Board;
            button43.Visible = Board;
            button44.Visible = Board;
            button45.Visible = Board;
            button46.Visible = Board;
            button47.Visible = Board;
            button48.Visible = Board;
            button49.Visible = Board;
            button50.Visible = Board;
            button51.Visible = Board;
            button52.Visible = Board;
            button53.Visible = Board;
            button54.Visible = Board;
            button55.Visible = Board;
            button56.Visible = Board;
            button57.Visible = Board;
            button58.Visible = Board;
            button59.Visible = Board;
            button60.Visible = Board;
            button61.Visible = Board;
            button62.Visible = Board;
            button63.Visible = Board;
            button64.Visible = Board;
            button65.Visible = Board;
            button66.Visible = Board;
            button67.Visible = Board;
            button68.Visible = Board;
            button69.Visible = Board;
            Deck.Visible = everythingelse;
            YourCard1.Visible = everythingelse;
            YourCard2.Visible = everythingelse;
            YourCard3.Visible = everythingelse;
            YourCard4.Visible = everythingelse;
            YourCard5.Visible = everythingelse;
            DownButton.Visible = Board;
        }

        public Form1()
        {
            //Builds the deck
            for (int i = 10; i > 0; i--)
            {
                //sets a certain amont of cards in deck
                for (int count = 0; count < -1 * (i - 10); count++)
                {
                    cardsowned = cardsowned.Concat(new string[] { (i).ToString() }).ToArray();
                    YourCards2 = YourCards2.Concat(new string[] { (i).ToString() }).ToArray();
                    ThereCards2 = ThereCards2.Concat(new string[] { (i).ToString() }).ToArray();
                }
            }
            for (int count = 0; count < 3; count++)
            {
                cardsowned = cardsowned.Concat(new string[] { "Switch two" }).ToArray();
                YourCards2 = YourCards2.Concat(new string[] { "Switch two" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Switch two" }).ToArray();
            }
            for (int count = 0; count < 1; count++)
            {
                cardsowned = cardsowned.Concat(new string[] { "Reset Your Deck" }).ToArray();
                YourCards2 = YourCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
            }
            for (int count = 0; count < 2; count++)
            {
                cardsowned = cardsowned.Concat(new string[] { "Search" }).ToArray();
                YourCards2 = YourCards2.Concat(new string[] { "Search" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Search" }).ToArray();
            }
            InitializeComponent();
        }
        
        private void AddCardIntoDeck(string card)
        {
            for(int count = 0; count < cardsowned.Length; count++)
            {
                if (card == cardsowned[count])
                {
                    cardsowned[count] = "0";
                    YourCards2 = YourCards2.Concat(new string[] { (card).ToString() }).ToArray();
                    UPButton.Text = card;
                    break;
                }
            }
            EditDeck();
        }

        private void EditDeck()
        {
            CardsInDeck.Visible = true;
            BackGroundBox.Visible = true;
            CloseEditDeck.Visible = true;
            int numberone = 0;
            int numbertwo = 0;
            int numberthree = 0;
            int numberfour = 0;
            int numberfive = 0;
            int numbersix = 0;
            int numberseven = 0;
            int numbereight = 0;
            int numbernine = 0;
            int Switchtwo = 0;
            int ResetYourDeck = 0;
            int Search = 0;
            foreach (string card in cardsowned)
            {
                if (card == "1")
                {
                    numberone++;
                }
                else if (card == "2")
                {
                    numbertwo++;
                }
                else if (card == "3")
                {
                    numberthree++;
                }
                else if (card == "4")
                {
                    numberfour++;
                }
                else if (card == "5")
                {
                    numberfive++;
                }
                else if (card == "6")
                {
                    numbersix++;
                }
                else if (card == "7")
                {
                    numberseven++;
                }
                else if (card == "8")
                {
                    numbereight++;
                }
                else if (card == "9")
                {
                    numbernine++;
                }
                else if (card == "Switch two")
                {
                    Switchtwo++;
                }
                else if (card == "Reset Your Deck")
                {
                    ResetYourDeck++;
                }
                else if (card == "Search")
                {
                    Search++;
                }
            }
            CardsOwned1.Text = "1";
            AmmountOfCards1.Text = numberone.ToString();
            CardsOwned2.Text = "2";
            AmmountOfCards2.Text = numbertwo.ToString();
            CardsOwned3.Text = "3";
            AmmountOfCards3.Text = numberthree.ToString();
            CardsOwned4.Text = "4";
            AmmountOfCards4.Text = numberfour.ToString();
            CardsOwned5.Text = "5";
            AmmountOfCards5.Text = numberfive.ToString();
            CardsOwned6.Text = "6";
            AmmountOfCards6.Text = numbersix.ToString();
            CardsOwned7.Text = "7";
            AmmountOfCards7.Text = numberseven.ToString();
            CardsOwned8.Text = "8";
            AmmountOfCards8.Text = numbereight.ToString();
            CardsOwned8.Text = "9";
            AmmountOfCards8.Text = numbernine.ToString();
            CardsOwned9.Text = "Switch two";
            AmmountOfCards9.Text = Switchtwo.ToString();
            CardsOwned10.Text = "Reset Your Deck";
            AmmountOfCards10.Text = ResetYourDeck.ToString();
            CardsOwned11.Text = "Search";
            AmmountOfCards11.Text = Search.ToString();
            CardsInDeck.Items.Clear();
            CardsInDeck.Items.Add("CardsInDeck");
            int NumberOfCardsInYourDeck = 0;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (YourCards2[count] != "0")
                {
                    NumberOfCardsInYourDeck++;
                }
            }
            //gets number of cards
            CardsInDeck.Items.Add(NumberOfCardsInYourDeck.ToString());
            foreach (string card in YourCards2)
            {
                if (card == "0"){ }
                else
                {
                    CardsInDeck.Items.Add(card);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 5; i > 0; i--)
            {
                setamountindeck();
                setcard(i);
                playingcard = true;
                while (true)
                {
                    int yournumber = rand.Next(1, ThereCards2.Length);
                    //10,11,12 are the extras
                    if (ThereCards2[yournumber] == "0")
                    { }
                    else
                    {
                        //This changes The card in your hand with a random card in your deck
                        if (i == 5)
                        {
                            ThereHand[0] = ThereCards2[yournumber];
                        }
                        else if (i == 4)
                        {
                            ThereHand[1] = ThereCards2[yournumber];
                        }
                        else if (i == 3)
                        {
                            ThereHand[2] = ThereCards2[yournumber];
                        }
                        else if (i == 2)
                        {
                            ThereHand[3] = ThereCards2[yournumber];
                        }
                        else if (i == 1)
                        {
                            ThereHand[4] = ThereCards2[yournumber];
                        }
                        YourCards2[yournumber] = "0";
                        break;
                    }
                }
            }
        }
        private void setcard(int i)
        {
            playingcard = true;
            while (true)
            {
                int yournumber = rand.Next(1, YourCards2.Length);
                //10,11,12 are the extras
                if (YourCards2[yournumber] == "0")
                { }
                else
                {
                    //This changes The card in your hand with a random card in your deck
                    if (i == 5)
                    {
                        CardNumber = YourCard1.Text;
                        YourCard1.Text = YourCards2[yournumber];
                    }
                    else if (i == 4)
                    {
                        CardNumber = YourCard2.Text;
                        YourCard2.Text = YourCards2[yournumber];
                    }
                    else if (i == 3)
                    {
                        CardNumber =YourCard3.Text;
                        YourCard3.Text = YourCards2[yournumber];
                    }
                    else if (i == 2)
                    {
                        CardNumber = YourCard4.Text;
                        YourCard4.Text = YourCards2[yournumber];
                    }
                    else if (i == 1)
                    {
                        CardNumber = YourCard5.Text;
                        YourCard5.Text = YourCards2[yournumber];
                    }
                    YourCards2[yournumber] = "0";
                    break;
                }
            }
        }

        private void openboard(int number)
        {
            bool Board = true;
            bool everythingelse = false;
            UPButton.Visible = everythingelse;
            A1.Visible = Board;
            button1.Visible = Board;
            button2.Visible = Board;
            button3.Visible = Board;
            button4.Visible = Board;
            button5.Visible = Board;
            button6.Visible = Board;
            button7.Visible = Board;
            button8.Visible = Board;
            button9.Visible = Board;
            button10.Visible = Board;
            button11.Visible = Board;
            button12.Visible = Board;
            button13.Visible = Board;
            button14.Visible = Board;
            button15.Visible = Board;
            button16.Visible = Board;
            button17.Visible = Board;
            button18.Visible = Board;
            button19.Visible = Board;
            button20.Visible = Board;
            button21.Visible = Board;
            button22.Visible = Board;
            button23.Visible = Board;
            button24.Visible = Board;
            button25.Visible = Board;
            button26.Visible = Board;
            button27.Visible = Board;
            button28.Visible = Board;
            button29.Visible = Board;
            button30.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button41.Visible = Board;
            button42.Visible = Board;
            button43.Visible = Board;
            button44.Visible = Board;
            button45.Visible = Board;
            button46.Visible = Board;
            button47.Visible = Board;
            button48.Visible = Board;
            button49.Visible = Board;
            button50.Visible = Board;
            button51.Visible = Board;
            button52.Visible = Board;
            button53.Visible = Board;
            button54.Visible = Board;
            button55.Visible = Board;
            button56.Visible = Board;
            button57.Visible = Board;
            button58.Visible = Board;
            button59.Visible = Board;
            button60.Visible = Board;
            button61.Visible = Board;
            button62.Visible = Board;
            button63.Visible = Board;
            button64.Visible = Board;
            button65.Visible = Board;
            button66.Visible = Board;
            button67.Visible = Board;
            button68.Visible = Board;
            button69.Visible = Board;
            Deck.Visible = everythingelse;
            YourCard1.Visible = everythingelse;
            YourCard2.Visible = everythingelse;
            YourCard3.Visible = everythingelse;
            YourCard4.Visible = everythingelse;
            YourCard5.Visible = everythingelse;
            DownButton.Visible = Board;
        }
        private void resetdeck()
        {
            //clears deck by setting all values to 0
            Array.Clear(YourCards2, 0, YourCards2.Length);
            for( int i=0 ; i < YourCards2.Length-1; i++)
            {
                YourCards2[i] = "0";
            }
            //Rebuils Deck
           for (int i = 10; i > 0; i--)
            {
                for (int count = 0; count < -1 * (i - 10); count++)
                {
                    YourCards2 = YourCards2.Concat(new string[] { (i).ToString() }).ToArray();
                    ThereCards2 = ThereCards2.Concat(new string[] { (i).ToString() }).ToArray();
                }
            }
            for (int count = 0; count < 3; count++)
            {
                YourCards2 = YourCards2.Concat( new string[] { "Switch two" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Switch two" }).ToArray();
            }
            for (int count = 0; count < 1; count++)
            {
                YourCards2 = YourCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
            }
            for (int count = 0; count < 2; count++)
            {
                YourCards2 = YourCards2.Concat(new string[] { "Search" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Search" }).ToArray();
            }
            //sets cards
            int cardnum = 5;
            while (true)
            {
                int yournumber = rand.Next(1, YourCards2.Length);
                //10,11,12 are the extras
                if (YourCards2[yournumber] == "0")
                { }
                else
                {
                    //Sets new cards in hand
                    if (cardnum == 5)
                    {
                        YourCard1.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 4)
                    {
                        YourCard2.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 3)
                    {
                        YourCard3.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 2)
                    {
                        YourCard4.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 1)
                    {
                        YourCard5.Text = YourCards2[yournumber];
                    }
                    YourCards2[yournumber] = "0";
                    cardnum--;
                    if (cardnum == 1)
                    {
                        break;
                    }
                }
            }
            setamountindeck();
        }
        int Skippingcards = 0;
        bool Search = true;
        private void search(int card)
        {   
            label1.Visible = true;
            label1.Text = "Search For a New Card In Your Deck";
            int Skipper = 0;
            Searchcard1.Visible = true;
            Searchcard2.Visible = true;
            Searchcard3.Visible = true;
            Searchcard4.Visible = true;
            SearchBack.Visible = true;
            SearchForward.Visible = true;
            Skipper = Skippingcards;
            foreach (string number in YourCards2)
            {
                if (number == "0") { }
                else
                {
                    if (Skipper == 0)
                    {
                        if (Searchcard1.Text == "Searchcard1")
                        {
                            Searchcard1.Text = number;
                        }
                        else if (Searchcard2.Text == "Searchcard2")
                        {
                            Searchcard2.Text = number;
                        }
                        else if (Searchcard3.Text == "Searchcard3")
                        {
                            Searchcard3.Text = number;
                        }
                        else if (Searchcard4.Text == "Searchcard4")
                        {
                            Searchcard4.Text = number;
                            break;
                        }
                    }
                    else
                    {
                        NumberOfCardsInYourDeckLabel.Text = Skippingcards.ToString();
                        Skipper--;
                    }
                }
            }
        }
        private void searchnext(int card)
        {
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            SwitchCard1.Text = "button1";
            SwitchCard2.Text = "button2";
            SwitchCard3.Text = "button3";
            SwitchCard4.Text = "button4";
            Skippingcards +=4;
            if (Search == true)
            {
                search(card);
            }
            else
            {
                SwitchInDeck();
            }
        }
        private void searchback(int card)
        {
            if (Skippingcards == 0) { }
            else
            {
                Searchcard1.Text = "Searchcard1";
                Searchcard2.Text = "Searchcard2";
                Searchcard3.Text = "Searchcard3";
                Searchcard4.Text = "Searchcard4";
                SwitchCard1.Text = "button1";
                SwitchCard2.Text = "button2";
                SwitchCard3.Text = "button3";
                SwitchCard4.Text = "button4";
                Skippingcards -= 4;
            }
            if (Search == true)
            {
                search(card);
            }
            else
            {
                SwitchInDeck();
            }
        }
        private void setamountindeck()
        {
            int NumberOfCardsInYourDeck = 0;
            for (int count = 0; count < YourCards2.Length-1; count++)
            {
                if (YourCards2[count] != "0")
                {
                    NumberOfCardsInYourDeck++;
                }
            }
            //gets number of cards
            Deck.Text = NumberOfCardsInYourDeck.ToString();
        }
        private void Clicked(int num)
        {
            setcard(num);
            setamountindeck();
        }
        private void SwitchInDeck()
        {
            int Skipper = 0;
            SwitchCard1.Visible = true;
            SwitchCard2.Visible = true;
            SwitchCard3.Visible = true;
            SwitchCard4.Visible = true;
            SearchBack.Visible = true;
            SearchForward.Visible = true;
            Skipper = Skippingcards;
            foreach (string number in YourCards2)
            {
                if (number == "0") { }
                else
                {
                    if (Skipper == 0)
                    {
                        if (SwitchCard1.Text == "button1")
                        {
                            SwitchCard1.Text = number;
                        }
                        else if (SwitchCard2.Text == "button2")
                        {
                            SwitchCard2.Text = number;
                        }
                        else if (SwitchCard3.Text == "button3")
                        {
                            SwitchCard3.Text = number;
                        }
                        else if (SwitchCard4.Text == "button4")
                        {
                            SwitchCard4.Text = number;
                            break;
                        }
                    }
                    else
                    {
                        Skipper--;
                    }
                }
            }
        }
        private void SwitchTwo(string card1, string card2, string card3, string card4)
        {
            label1.Visible = true;
            label1.Text = "Pick 2 cards in you Hand";
            label1.Visible = true;
            PickCardFromHand4.Visible = true;
            PickCardFromHand3.Visible = true;
            PickCardFromHand2.Visible = true;
            PickCardFromHand1.Visible = true;
            PickCardFromHand4.Text = card1;
            PickCardFromHand3.Text = card2;
            PickCardFromHand2.Text = card3;
            PickCardFromHand1.Text = card4;
        }
        int cardnum = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            cardnum = 1;
            if (YourCard5.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard5.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard5.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text, YourCard2.Text, YourCard3.Text, YourCard4.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
                openboard(cardnum);
                CardsPlayed++;
                if (CardsPlayed >= 3)
                {
                    ISAITurn = true;
                    openboard(1);
                    DownButton.Visible = false;
                    CardsPlayed = 0;

                }
                else if (CardsPlayed >= 3 && ISAITurn == true)
                {
                    ISAITurn = false;
                    bool Board = false;
                    bool everythingelse = true;
                    UPButton.Visible = everythingelse;
                    A1.Visible = Board;
                    button1.Visible = Board;
                    button2.Visible = Board;
                    button3.Visible = Board;
                    button4.Visible = Board;
                    button5.Visible = Board;
                    button6.Visible = Board;
                    button7.Visible = Board;
                    button8.Visible = Board;
                    button9.Visible = Board;
                    button10.Visible = Board;
                    button11.Visible = Board;
                    button12.Visible = Board;
                    button13.Visible = Board;
                    button14.Visible = Board;
                    button15.Visible = Board;
                    button16.Visible = Board;
                    button17.Visible = Board;
                    button18.Visible = Board;
                    button19.Visible = Board;
                    button20.Visible = Board;
                    button21.Visible = Board;
                    button22.Visible = Board;
                    button23.Visible = Board;
                    button24.Visible = Board;
                    button25.Visible = Board;
                    button26.Visible = Board;
                    button27.Visible = Board;
                    button28.Visible = Board;
                    button29.Visible = Board;
                    button30.Visible = Board;
                    button31.Visible = Board;
                    button32.Visible = Board;
                    button33.Visible = Board;
                    button34.Visible = Board;
                    button35.Visible = Board;
                    button36.Visible = Board;
                    button37.Visible = Board;
                    button38.Visible = Board;
                    button39.Visible = Board;
                    button40.Visible = Board;
                    button31.Visible = Board;
                    button32.Visible = Board;
                    button33.Visible = Board;
                    button34.Visible = Board;
                    button35.Visible = Board;
                    button36.Visible = Board;
                    button37.Visible = Board;
                    button38.Visible = Board;
                    button39.Visible = Board;
                    button40.Visible = Board;
                    button41.Visible = Board;
                    button42.Visible = Board;
                    button43.Visible = Board;
                    button44.Visible = Board;
                    button45.Visible = Board;
                    button46.Visible = Board;
                    button47.Visible = Board;
                    button48.Visible = Board;
                    button49.Visible = Board;
                    button50.Visible = Board;
                    button51.Visible = Board;
                    button52.Visible = Board;
                    button53.Visible = Board;
                    button54.Visible = Board;
                    button55.Visible = Board;
                    button56.Visible = Board;
                    button57.Visible = Board;
                    button58.Visible = Board;
                    button59.Visible = Board;
                    button60.Visible = Board;
                    button61.Visible = Board;
                    button62.Visible = Board;
                    button63.Visible = Board;
                    button64.Visible = Board;
                    button65.Visible = Board;
                    button66.Visible = Board;
                    button67.Visible = Board;
                    button68.Visible = Board;
                    button69.Visible = Board;
                    Deck.Visible = everythingelse;
                    YourCard1.Visible = everythingelse;
                    YourCard2.Visible = everythingelse;
                    YourCard3.Visible = everythingelse;
                    YourCard4.Visible = everythingelse;
                    YourCard5.Visible = everythingelse;
                    DownButton.Visible = Board;
                }
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            cardnum = 2;
            if (YourCard4.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard4.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard4.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text,YourCard2.Text,YourCard3.Text,YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
                openboard(cardnum);
                CardsPlayed++;
                if (CardsPlayed >= 3)
                {
                    ISAITurn = true;
                    openboard(1);
                    DownButton.Visible = false;
                    CardsPlayed = 0;
                    AI();

                }
                else if (CardsPlayed >= 3 && ISAITurn == true)
                {
                    ISAITurn = false;
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            cardnum = 3;
            if (YourCard3.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard3.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard3.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text, YourCard2.Text, YourCard4.Text, YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
                openboard(cardnum);
                CardsPlayed++;
                if (CardsPlayed >= 3)
                {
                    ISAITurn = true;
                    openboard(1);
                    DownButton.Visible = false;
                    CardsPlayed = 0;
                    AI();

                }
                else if (CardsPlayed >= 3 && ISAITurn == true)
                {
                    ISAITurn = false;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cardnum = 4;
            if (YourCard2.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard2.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard2.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text, YourCard3.Text, YourCard4.Text, YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
                openboard(cardnum);
                CardsPlayed++;
                if (CardsPlayed >= 3)
                {
                    ISAITurn = true;
                    openboard(1);
                    DownButton.Visible = false;
                    CardsPlayed = 0;
                    AI();

                }
                else if (CardsPlayed >= 3 && ISAITurn == true)
                {
                    ISAITurn = false;
                }
            }
        }

        private void YourCard1_Click(object sender, EventArgs e)
        {
            cardnum = 5;
            if (YourCard1.Text == "Reset Your Deck")
            {
                resetdeck();
            }
           else if (YourCard1.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard1.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard2.Text, YourCard3.Text, YourCard4.Text, YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
                openboard(cardnum);
                CardsPlayed++;
                if (CardsPlayed >= 3)
                {
                    ISAITurn = true;
                    openboard(1);
                    DownButton.Visible = false;
                    CardsPlayed = 0;
                    AI();

                }
                else if (CardsPlayed >= 3 && ISAITurn == true)
                {
                    ISAITurn = false;
                }
            }
        }

        private void SearchForward_Click(object sender, EventArgs e)
        {
            searchnext(cardnum);
        }

        private void SearchBack_Click(object sender, EventArgs e)
        {
            searchback(cardnum);
        }

        private void Searchcard1_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard1.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text==YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        private void Searchcard2_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard2.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text == YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        private void Searchcard3_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard3.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text == YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        private void Searchcard4_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard4.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text == YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        string[] CardsInHand = new string[] { "0", "0" };
        private void PickCardFromHand1_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand1.Text;
                PickCardFromHand1.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand1.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void PickCardFromHand2_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand2.Text;
                PickCardFromHand2.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand2.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void PickCardFromHand3_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand3.Text;
                PickCardFromHand3.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand3.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void PickCardFromHand4_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand4.Text;
                PickCardFromHand4.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand4.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void SwitchCard4_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard4.Text;
            SwitchCard4.Visible = false;
            if (CardsInHand[0] == "0")
            {
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }

        private void SwitchCard3_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard3.Text;
            SwitchCard3.Visible = false;
            if (CardsInHand[0] == "0")
            {
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }

        private void SwitchCard2_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard2.Text;
            SwitchCard2.Visible = false;
            if (CardsInHand[0] == "0")
            {
                for (int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[1];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                for (int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[0];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }

        private void SwitchCard1_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard1.Text;
            SwitchCard1.Visible = false;
            if (CardsInHand[0] == "0")
            {
                for(int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[1];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                for (int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[0];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void A1_Click(object sender, EventArgs e)
        {

        }

        private void UPButton_Click(object sender, EventArgs e)
        {
            playingcard = false;
            bool Board = true;
            bool everythingelse = false;
            UPButton.Visible = everythingelse;
            A1.Visible = Board;
            button1.Visible = Board;
            button2.Visible = Board;
            button3.Visible = Board;
            button4.Visible = Board;
            button5.Visible = Board;
            button6.Visible = Board;
            button7.Visible = Board;
            button8.Visible = Board;
            button9.Visible = Board;
            button10.Visible = Board;
            button11.Visible = Board;
            button12.Visible = Board;
            button13.Visible = Board;
            button14.Visible = Board;
            button15.Visible = Board;
            button16.Visible = Board;
            button17.Visible = Board;
            button18.Visible = Board;
            button19.Visible = Board;
            button20.Visible = Board;
            button21.Visible = Board;
            button22.Visible = Board;
            button23.Visible = Board;
            button24.Visible = Board;
            button25.Visible = Board;
            button26.Visible = Board;
            button27.Visible = Board;
            button28.Visible = Board;
            button29.Visible = Board;
            button30.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button41.Visible = Board;
            button42.Visible = Board;
            button43.Visible = Board;
            button44.Visible = Board;
            button45.Visible = Board;
            button46.Visible = Board;
            button47.Visible = Board;
            button48.Visible = Board;
            button49.Visible = Board;
            button50.Visible = Board;
            button51.Visible = Board;
            button52.Visible = Board;
            button53.Visible = Board;
            button54.Visible = Board;
            button55.Visible = Board;
            button56.Visible = Board;
            button57.Visible = Board;
            button58.Visible = Board;
            button59.Visible = Board;
            button60.Visible = Board;
            button61.Visible = Board;
            button62.Visible = Board;
            button63.Visible = Board;
            button64.Visible = Board;
            button65.Visible = Board;
            button66.Visible = Board;
            button67.Visible = Board;
            button68.Visible = Board;
            button69.Visible = Board;
            Deck.Visible = everythingelse;
            YourCard1.Visible = everythingelse;
            YourCard2.Visible = everythingelse;
            YourCard3.Visible = everythingelse;
            YourCard4.Visible = everythingelse;
            YourCard5.Visible = everythingelse;
            DownButton.Visible = Board;
        }

        private void DownButton_Click(object sender, EventArgs e)
        {
            bool Board = false;
            bool everythingelse = true;
            UPButton.Visible = everythingelse;
            A1.Visible = Board;
            button1.Visible = Board;
            button2.Visible = Board;
            button3.Visible = Board;
            button4.Visible = Board;
            button5.Visible = Board;
            button6.Visible = Board;
            button7.Visible = Board;
            button8.Visible = Board;
            button9.Visible = Board;
            button10.Visible = Board;
            button11.Visible = Board;
            button12.Visible = Board;
            button13.Visible = Board;
            button14.Visible = Board;
            button15.Visible = Board;
            button16.Visible = Board;
            button17.Visible = Board;
            button18.Visible = Board;
            button19.Visible = Board;
            button20.Visible = Board;
            button21.Visible = Board;
            button22.Visible = Board;
            button23.Visible = Board;
            button24.Visible = Board;
            button25.Visible = Board;
            button26.Visible = Board;
            button27.Visible = Board;
            button28.Visible = Board;
            button29.Visible = Board;
            button30.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button31.Visible = Board;
            button32.Visible = Board;
            button33.Visible = Board;
            button34.Visible = Board;
            button35.Visible = Board;
            button36.Visible = Board;
            button37.Visible = Board;
            button38.Visible = Board;
            button39.Visible = Board;
            button40.Visible = Board;
            button41.Visible = Board;
            button42.Visible = Board;
            button43.Visible = Board;
            button44.Visible = Board;
            button45.Visible = Board;
            button46.Visible = Board;
            button47.Visible = Board;
            button48.Visible = Board;
            button49.Visible = Board;
            button50.Visible = Board;
            button51.Visible = Board;
            button52.Visible = Board;
            button53.Visible = Board;
            button54.Visible = Board;
            button55.Visible = Board;
            button56.Visible = Board;
            button57.Visible = Board;
            button58.Visible = Board;
            button59.Visible = Board;
            button60.Visible = Board;
            button61.Visible = Board;
            button62.Visible = Board;
            button63.Visible = Board;
            button64.Visible = Board;
            button65.Visible = Board;
            button66.Visible = Board;
            button67.Visible = Board;
            button68.Visible = Board;
            button69.Visible = Board;
            Deck.Visible = everythingelse;
            YourCard1.Visible = everythingelse;
            YourCard2.Visible = everythingelse;
            YourCard3.Visible = everythingelse;
            YourCard4.Visible = everythingelse;
            YourCard5.Visible = everythingelse;
            DownButton.Visible = Board;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void button60_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button60.Text;
                if (buttontext == "")
                {
                    button60.Text = CardNumber.ToString();
                }
                else
                {
                    button60.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button61_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button61.Text;
                if (buttontext == "")
                {
                    button61.Text = CardNumber.ToString();
                }
                else
                {
                    button61.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button62_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button62.Text;
                if (buttontext == "")
                {
                    button62.Text = CardNumber.ToString();
                }
                else
                {
                    button62.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button63_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button63.Text;
                if (buttontext == "")
                {
                    button63.Text = CardNumber.ToString();
                }
                else
                {
                    button63.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button64_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button64.Text;
                if (buttontext == "")
                {
                    button64.Text = CardNumber.ToString();
                }
                else
                {
                    button64.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button65_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button65.Text;
                if (buttontext == "")
                {
                    button65.Text = CardNumber.ToString();
                }
                else
                {
                    button65.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button66_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button66.Text;
                if (buttontext == "")
                {
                    button66.Text = CardNumber.ToString();
                }
                else
                {
                    button66.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button67_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button67.Text;
                if (buttontext == "")
                {
                    button67.Text = CardNumber.ToString();
                }
                else
                {
                    button67.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button68_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button68.Text;
                if (buttontext == "")
                {
                    button68.Text = CardNumber.ToString();
                }
                else
                {
                    button68.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void button69_Click(object sender, EventArgs e)
        {
            if (playingcard)
            {
                string buttontext = button69.Text;
                if (buttontext == "")
                {
                    button69.Text = CardNumber.ToString();
                }
                else
                {
                    button69.Text = (Int32.Parse(buttontext) + Int32.Parse(CardNumber)).ToString();
                }
                CardNumber = "0";
                playingcard = false;
            }
        }

        private void AmmountOfCards10_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned1.Text);
        }

        private void CardsOwned1_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned1.Text);
        }

        private void CardsOwned2_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned2.Text);
        }

        private void CardsOwned3_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned3.Text);
        }

        private void CardsOwned4_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned4.Text);
        }

        private void CardsOwned5_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned5.Text);
        }

        private void CardsOwned6_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned6.Text);
        }

        private void CardsOwned7_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned7.Text);
        }

        private void CardsOwned8_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned8.Text);
        }

        private void CardsOwned9_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned9.Text);
        }

        private void CardsOwned10_Click(object sender, EventArgs e)
        {
            AddCardIntoDeck(CardsOwned10.Text);
        }

        private void Open_Click(object sender, EventArgs e)
        {
            EditDeck();
        }

        private void CloseEditDeck_Click(object sender, EventArgs e)
        {
            CloseEditDeck.Visible = false;
            BackGroundBox.Visible = false;
            CardsInDeck.Visible = false;
            for (int i = 5; i > 0; i--)
            {
                setamountindeck();
                setcard(i);
                playingcard = true;
                while (true)
                {
                    int yournumber = rand.Next(1, ThereCards2.Length);
                    //10,11,12 are the extras
                    if (ThereCards2[yournumber] == "0")
                    { }
                    else
                    {
                        //This changes The card in your hand with a random card in your deck
                        if (i == 5)
                        {
                            ThereHand[0] = ThereCards2[yournumber];
                        }
                        else if (i == 4)
                        {
                            ThereHand[1] = ThereCards2[yournumber];
                        }
                        else if (i == 3)
                        {
                            ThereHand[2] = ThereCards2[yournumber];
                        }
                        else if (i == 2)
                        {
                            ThereHand[3] = ThereCards2[yournumber];
                        }
                        else if (i == 1)
                        {
                            ThereHand[4] = ThereCards2[yournumber];
                        }
                        YourCards2[yournumber] = "0";
                        break;
                    }
                }
            }
        }
    }
}
