﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Collections;

namespace Game
{
    public partial class Form1 : Form
    {
        Random rand = new Random();
        string[] YourCards2 = new string[] { };
        string[] ThereCards2 = new string[] { };
        int CardsPlayed = 0;
        public Form1()
        {
            //Builds the deck
            for (int i = 10; i > 0; i--)
            {
                //sets a certain amont of cards in deck
                for (int count = 0; count < -1 * (i - 10); count++)
                {
                    YourCards2 = YourCards2.Concat(new string[] { (i).ToString() }).ToArray();
                    ThereCards2 = ThereCards2.Concat(new string[] { (i).ToString() }).ToArray();
                }
            }
            for (int count = 0; count < 3; count++)
            {
                YourCards2 = YourCards2.Concat(new string[] { "Switch two" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Switch two" }).ToArray();
            }
            for (int count = 0; count < 1; count++)
            {
                YourCards2 = YourCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
            }
            for (int count = 0; count < 2; count++)
            {
                YourCards2 = YourCards2.Concat(new string[] { "Search" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Search" }).ToArray();
            }
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 5; i > 0; i--)
            {
                setamountindeck();
                setcard(i);
            }
        }
        private void setcard(int i)
        {
            while (true)
            {
                int yournumber = rand.Next(1, YourCards2.Length);
                //10,11,12 are the extras
                if (YourCards2[yournumber] == "0")
                { }
                else
                {
                    //This changes The card in your hand with a random card in your deck
                    if (i == 5)
                    {
                        YourCard1.Text = YourCards2[yournumber];
                    }
                    else if (i == 4)
                    {
                        YourCard2.Text = YourCards2[yournumber];
                    }
                    else if (i == 3)
                    {
                        YourCard3.Text = YourCards2[yournumber];
                    }
                    else if (i == 2)
                    {
                        YourCard4.Text = YourCards2[yournumber];
                    }
                    else if (i == 1)
                    {
                        YourCard5.Text = YourCards2[yournumber];
                    }
                    YourCards2[yournumber] = "0";
                    break;
                }
            }
        }
        private void resetdeck()
        {
            //clears deck by setting all values to 0
            Array.Clear(YourCards2, 0, YourCards2.Length);
            for( int i=0 ; i < YourCards2.Length-1; i++)
            {
                YourCards2[i] = "0";
            }
            //Rebuils Deck
           for (int i = 10; i > 0; i--)
            {
                for (int count = 0; count < -1 * (i - 10); count++)
                {
                    YourCards2 = YourCards2.Concat(new string[] { (i).ToString() }).ToArray();
                    ThereCards2 = ThereCards2.Concat(new string[] { (i).ToString() }).ToArray();
                }
            }
            for (int count = 0; count < 3; count++)
            {
                YourCards2 = YourCards2.Concat( new string[] { "Switch two" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Switch two" }).ToArray();
            }
            for (int count = 0; count < 1; count++)
            {
                YourCards2 = YourCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Reset Your Deck" }).ToArray();
            }
            for (int count = 0; count < 2; count++)
            {
                YourCards2 = YourCards2.Concat(new string[] { "Search" }).ToArray();
                ThereCards2 = ThereCards2.Concat(new string[] { "Search" }).ToArray();
            }
            //sets cards
            int cardnum = 5;
            while (true)
            {
                int yournumber = rand.Next(1, YourCards2.Length);
                //10,11,12 are the extras
                if (YourCards2[yournumber] == "0")
                { }
                else
                {
                    //Sets new cards in hand
                    if (cardnum == 5)
                    {
                        YourCard1.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 4)
                    {
                        YourCard2.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 3)
                    {
                        YourCard3.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 2)
                    {
                        YourCard4.Text = YourCards2[yournumber];
                    }
                    else if (cardnum == 1)
                    {
                        YourCard5.Text = YourCards2[yournumber];
                    }
                    YourCards2[yournumber] = "0";
                    cardnum--;
                    if (cardnum == 1)
                    {
                        break;
                    }
                }
            }
            setamountindeck();
        }
        int Skippingcards = 0;
        bool Search = true;
        private void search(int card)
        {
            label1.Visible = true;
            label1.Text = "Search For a New Card In Your Deck";
            int Skipper = 0;
            Searchcard1.Visible = true;
            Searchcard2.Visible = true;
            Searchcard3.Visible = true;
            Searchcard4.Visible = true;
            SearchBack.Visible = true;
            SearchForward.Visible = true;
            Skipper = Skippingcards;
            foreach (string number in YourCards2)
            {
                if (number == "0") { }
                else
                {
                    if (Skipper == 0)
                    {
                        if (Searchcard1.Text == "Searchcard1")
                        {
                            Searchcard1.Text = number;
                        }
                        else if (Searchcard2.Text == "Searchcard2")
                        {
                            Searchcard2.Text = number;
                        }
                        else if (Searchcard3.Text == "Searchcard3")
                        {
                            Searchcard3.Text = number;
                        }
                        else if (Searchcard4.Text == "Searchcard4")
                        {
                            Searchcard4.Text = number;
                            break;
                        }
                    }
                    else
                    {
                        NumberOfCardsInYourDeckLabel.Text = Skippingcards.ToString();
                        Skipper--;
                    }
                }
            }
        }
        private void searchnext(int card)
        {
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            SwitchCard1.Text = "button1";
            SwitchCard2.Text = "button2";
            SwitchCard3.Text = "button3";
            SwitchCard4.Text = "button4";
            Skippingcards +=4;
            if (Search == true)
            {
                search(card);
            }
            else
            {
                SwitchInDeck();
            }
        }
        private void searchback(int card)
        {
            if (Skippingcards == 0) { }
            else
            {
                Searchcard1.Text = "Searchcard1";
                Searchcard2.Text = "Searchcard2";
                Searchcard3.Text = "Searchcard3";
                Searchcard4.Text = "Searchcard4";
                SwitchCard1.Text = "button1";
                SwitchCard2.Text = "button2";
                SwitchCard3.Text = "button3";
                SwitchCard4.Text = "button4";
                Skippingcards -= 4;
            }
            if (Search == true)
            {
                search(card);
            }
            else
            {
                SwitchInDeck();
            }
        }
        private void setamountindeck()
        {
            int NumberOfCardsInYourDeck = 0;
            for (int count = 0; count < YourCards2.Length-1; count++)
            {
                if (YourCards2[count] != "0")
                {
                    NumberOfCardsInYourDeck++;
                }
            }
            //gets number of cards
            Deck.Text = NumberOfCardsInYourDeck.ToString();
        }
        private void Clicked(int num)
        {
            setcard(num);
            setamountindeck();
        }
        private void SwitchInDeck()
        {
            int Skipper = 0;
            SwitchCard1.Visible = true;
            SwitchCard2.Visible = true;
            SwitchCard3.Visible = true;
            SwitchCard4.Visible = true;
            SearchBack.Visible = true;
            SearchForward.Visible = true;
            Skipper = Skippingcards;
            foreach (string number in YourCards2)
            {
                if (number == "0") { }
                else
                {
                    if (Skipper == 0)
                    {
                        if (SwitchCard1.Text == "button1")
                        {
                            SwitchCard1.Text = number;
                        }
                        else if (SwitchCard2.Text == "button2")
                        {
                            SwitchCard2.Text = number;
                        }
                        else if (SwitchCard3.Text == "button3")
                        {
                            SwitchCard3.Text = number;
                        }
                        else if (SwitchCard4.Text == "button4")
                        {
                            SwitchCard4.Text = number;
                            break;
                        }
                    }
                    else
                    {
                        Skipper--;
                    }
                }
            }
        }
        private void SwitchTwo(string card1, string card2, string card3, string card4)
        {
            label1.Visible = true;
            label1.Text = "Pick 2 cards in you Hand";
            label1.Visible = true;
            PickCardFromHand4.Visible = true;
            PickCardFromHand3.Visible = true;
            PickCardFromHand2.Visible = true;
            PickCardFromHand1.Visible = true;
            PickCardFromHand4.Text = card1;
            PickCardFromHand3.Text = card2;
            PickCardFromHand2.Text = card3;
            PickCardFromHand1.Text = card4;
        }

        int cardnum = 0;

        private void button4_Click(object sender, EventArgs e)
        {
            cardnum = 1;
            if (YourCard5.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard5.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard5.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text, YourCard2.Text, YourCard3.Text, YourCard4.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            cardnum = 2;
            if (YourCard4.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard4.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard4.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text,YourCard2.Text,YourCard3.Text,YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cardnum = 3;
            if (YourCard3.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard3.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard3.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text, YourCard2.Text, YourCard4.Text, YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            cardnum = 4;
            if (YourCard2.Text == "Reset Your Deck")
            {
                resetdeck();
            }
            else if (YourCard2.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard2.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard1.Text, YourCard3.Text, YourCard4.Text, YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
            }
        }

        private void YourCard1_Click(object sender, EventArgs e)
        {
            cardnum = 5;
            if (YourCard1.Text == "Reset Your Deck")
            {
                resetdeck();
            }
           else if (YourCard1.Text == "Search")
            {
                Search = true;
                search(cardnum);
            }
            else if (YourCard1.Text == "Switch two")
            {
                Search = false;
                SwitchTwo(YourCard2.Text, YourCard3.Text, YourCard4.Text, YourCard5.Text);
                Clicked(cardnum);
            }
            else
            {
                Clicked(cardnum);
            }
        }

        private void SearchForward_Click(object sender, EventArgs e)
        {
            searchnext(cardnum);
        }

        private void SearchBack_Click(object sender, EventArgs e)
        {
            searchback(cardnum);
        }

        private void Searchcard1_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard1.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text==YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        private void Searchcard2_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard2.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text == YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        private void Searchcard3_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard3.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text == YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        private void Searchcard4_Click(object sender, EventArgs e)
        {
            Searchcard1.Visible = false;
            Searchcard2.Visible = false;
            Searchcard3.Visible = false;
            Searchcard4.Visible = false;
            SearchBack.Visible = false;
            SearchForward.Visible = false;
            string text = Searchcard4.Text;
            for (int count = 0; count < YourCards2.Length - 1; count++)
            {
                if (text == YourCards2[count])
                {
                    YourCards2[count] = "0";
                    break;
                }
            }
            if (cardnum == 1)
            {
                YourCard5.Text = text;
            }
            else if (cardnum == 2)
            {
                YourCard4.Text = text;
            }
            if (cardnum == 3)
            {
                YourCard3.Text = text;
            }
            if (cardnum == 4)
            {
                YourCard2.Text = text;
            }
            if (cardnum == 5)
            {
                YourCard1.Text = text;
            }
            Searchcard1.Text = "Searchcard1";
            Searchcard2.Text = "Searchcard2";
            Searchcard3.Text = "Searchcard3";
            Searchcard4.Text = "Searchcard4";
            setamountindeck();
        }

        string[] CardsInHand = new string[] { "0", "0" };
        private void PickCardFromHand1_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand1.Text;
                PickCardFromHand1.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand1.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void PickCardFromHand2_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand2.Text;
                PickCardFromHand2.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand2.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void PickCardFromHand3_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand3.Text;
                PickCardFromHand3.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand3.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void PickCardFromHand4_Click(object sender, EventArgs e)
        {
            if (CardsInHand[0] == "0")
            {
                CardsInHand[0] = PickCardFromHand4.Text;
                PickCardFromHand4.Visible = false;
            }
            else
            {
                CardsInHand[1] = PickCardFromHand4.Text;
                PickCardFromHand1.Visible = false;
                PickCardFromHand2.Visible = false;
                PickCardFromHand3.Visible = false;
                PickCardFromHand4.Visible = false;
                SwitchInDeck();
            }
        }

        private void SwitchCard4_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard4.Text;
            SwitchCard4.Visible = false;
            if (CardsInHand[0] == "0")
            {
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }

        private void SwitchCard3_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard3.Text;
            SwitchCard3.Visible = false;
            if (CardsInHand[0] == "0")
            {
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }

        private void SwitchCard2_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard2.Text;
            SwitchCard2.Visible = false;
            if (CardsInHand[0] == "0")
            {
                for (int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[1];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                for (int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[0];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }

        private void SwitchCard1_Click(object sender, EventArgs e)
        {
            string ThisCard = SwitchCard1.Text;
            SwitchCard1.Visible = false;
            if (CardsInHand[0] == "0")
            {
                for(int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[1];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[1])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[1])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[1])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[1])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[1])
                {
                    YourCard5.Text = ThisCard;
                }
                SwitchCard1.Visible = false;
                SwitchCard1.Text = "button1";
                SwitchCard2.Visible = false;
                SwitchCard2.Text = "button2";
                SwitchCard3.Visible = false;
                SwitchCard3.Text = "button3";
                SwitchCard4.Visible = false;
                SwitchCard4.Text = "button4";
                SearchBack.Visible = false;
                SearchForward.Visible = false;
            }
            else
            {
                for (int count = 0; count < YourCards2.Length; count++)
                {
                    if (YourCards2[count] == ThisCard)
                    {
                        YourCards2[count] = CardsInHand[0];
                        break;
                    }
                }
                if (YourCard1.Text == CardsInHand[0])
                {
                    YourCard1.Text = ThisCard;
                }
                else if (YourCard2.Text == CardsInHand[0])
                {
                    YourCard2.Text = ThisCard;
                }
                else if (YourCard3.Text == CardsInHand[0])
                {
                    YourCard3.Text = ThisCard;
                }
                else if (YourCard4.Text == CardsInHand[0])
                {
                    YourCard4.Text = ThisCard;
                }
                else if (YourCard5.Text == CardsInHand[0])
                {
                    YourCard5.Text = ThisCard;
                }
                PickCardFromHand1.Visible = false;
                CardsInHand[0] = "0";
            }
        }
    }
}
