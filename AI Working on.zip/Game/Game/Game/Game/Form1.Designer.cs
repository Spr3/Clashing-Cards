﻿
namespace Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NumberOfCardsInYourDeckLabel = new System.Windows.Forms.Label();
            this.YourCard1 = new System.Windows.Forms.Button();
            this.YourCard2 = new System.Windows.Forms.Button();
            this.YourCard3 = new System.Windows.Forms.Button();
            this.YourCard4 = new System.Windows.Forms.Button();
            this.YourCard5 = new System.Windows.Forms.Button();
            this.Deck = new System.Windows.Forms.Button();
            this.Searchcard1 = new System.Windows.Forms.Button();
            this.Searchcard2 = new System.Windows.Forms.Button();
            this.Searchcard3 = new System.Windows.Forms.Button();
            this.Searchcard4 = new System.Windows.Forms.Button();
            this.SearchBack = new System.Windows.Forms.Button();
            this.SearchForward = new System.Windows.Forms.Button();
            this.SwitchCard4 = new System.Windows.Forms.Button();
            this.SwitchCard3 = new System.Windows.Forms.Button();
            this.SwitchCard2 = new System.Windows.Forms.Button();
            this.SwitchCard1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.PickCardFromHand1 = new System.Windows.Forms.Button();
            this.PickCardFromHand2 = new System.Windows.Forms.Button();
            this.PickCardFromHand3 = new System.Windows.Forms.Button();
            this.PickCardFromHand4 = new System.Windows.Forms.Button();
            this.ThereCard5 = new System.Windows.Forms.Button();
            this.ThereCard4 = new System.Windows.Forms.Button();
            this.ThereCard3 = new System.Windows.Forms.Button();
            this.ThereCard2 = new System.Windows.Forms.Button();
            this.ThereCard1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NumberOfCardsInYourDeckLabel
            // 
            this.NumberOfCardsInYourDeckLabel.AutoSize = true;
            this.NumberOfCardsInYourDeckLabel.Location = new System.Drawing.Point(653, 281);
            this.NumberOfCardsInYourDeckLabel.Name = "NumberOfCardsInYourDeckLabel";
            this.NumberOfCardsInYourDeckLabel.Size = new System.Drawing.Size(33, 13);
            this.NumberOfCardsInYourDeckLabel.TabIndex = 4;
            this.NumberOfCardsInYourDeckLabel.Text = "Deck";
            // 
            // YourCard1
            // 
            this.YourCard1.Location = new System.Drawing.Point(47, 297);
            this.YourCard1.Name = "YourCard1";
            this.YourCard1.Size = new System.Drawing.Size(100, 141);
            this.YourCard1.TabIndex = 5;
            this.YourCard1.Text = "button1";
            this.YourCard1.UseVisualStyleBackColor = true;
            this.YourCard1.Click += new System.EventHandler(this.YourCard1_Click);
            // 
            // YourCard2
            // 
            this.YourCard2.Location = new System.Drawing.Point(153, 297);
            this.YourCard2.Name = "YourCard2";
            this.YourCard2.Size = new System.Drawing.Size(100, 141);
            this.YourCard2.TabIndex = 6;
            this.YourCard2.Text = "button1";
            this.YourCard2.UseVisualStyleBackColor = true;
            this.YourCard2.Click += new System.EventHandler(this.button2_Click);
            // 
            // YourCard3
            // 
            this.YourCard3.Location = new System.Drawing.Point(259, 297);
            this.YourCard3.Name = "YourCard3";
            this.YourCard3.Size = new System.Drawing.Size(100, 141);
            this.YourCard3.TabIndex = 7;
            this.YourCard3.Text = "button1";
            this.YourCard3.UseVisualStyleBackColor = true;
            this.YourCard3.Click += new System.EventHandler(this.button1_Click);
            // 
            // YourCard4
            // 
            this.YourCard4.Location = new System.Drawing.Point(365, 297);
            this.YourCard4.Name = "YourCard4";
            this.YourCard4.Size = new System.Drawing.Size(100, 141);
            this.YourCard4.TabIndex = 8;
            this.YourCard4.Text = "button1";
            this.YourCard4.UseVisualStyleBackColor = true;
            this.YourCard4.Click += new System.EventHandler(this.button3_Click);
            // 
            // YourCard5
            // 
            this.YourCard5.Location = new System.Drawing.Point(471, 297);
            this.YourCard5.Name = "YourCard5";
            this.YourCard5.Size = new System.Drawing.Size(100, 141);
            this.YourCard5.TabIndex = 9;
            this.YourCard5.Text = "button1";
            this.YourCard5.UseVisualStyleBackColor = true;
            this.YourCard5.Click += new System.EventHandler(this.button4_Click);
            // 
            // Deck
            // 
            this.Deck.Location = new System.Drawing.Point(656, 297);
            this.Deck.Name = "Deck";
            this.Deck.Size = new System.Drawing.Size(100, 141);
            this.Deck.TabIndex = 10;
            this.Deck.Text = "button1";
            this.Deck.UseVisualStyleBackColor = true;
            // 
            // Searchcard1
            // 
            this.Searchcard1.Location = new System.Drawing.Point(64, 87);
            this.Searchcard1.Name = "Searchcard1";
            this.Searchcard1.Size = new System.Drawing.Size(158, 251);
            this.Searchcard1.TabIndex = 11;
            this.Searchcard1.Text = "Searchcard1";
            this.Searchcard1.UseVisualStyleBackColor = true;
            this.Searchcard1.Visible = false;
            this.Searchcard1.Click += new System.EventHandler(this.Searchcard1_Click);
            // 
            // Searchcard2
            // 
            this.Searchcard2.Location = new System.Drawing.Point(228, 87);
            this.Searchcard2.Name = "Searchcard2";
            this.Searchcard2.Size = new System.Drawing.Size(158, 251);
            this.Searchcard2.TabIndex = 12;
            this.Searchcard2.Text = "Searchcard2";
            this.Searchcard2.UseVisualStyleBackColor = true;
            this.Searchcard2.Visible = false;
            this.Searchcard2.Click += new System.EventHandler(this.Searchcard2_Click);
            // 
            // Searchcard3
            // 
            this.Searchcard3.Location = new System.Drawing.Point(392, 87);
            this.Searchcard3.Name = "Searchcard3";
            this.Searchcard3.Size = new System.Drawing.Size(158, 251);
            this.Searchcard3.TabIndex = 13;
            this.Searchcard3.Text = "Searchcard3";
            this.Searchcard3.UseVisualStyleBackColor = true;
            this.Searchcard3.Visible = false;
            this.Searchcard3.Click += new System.EventHandler(this.Searchcard3_Click);
            // 
            // Searchcard4
            // 
            this.Searchcard4.Location = new System.Drawing.Point(556, 87);
            this.Searchcard4.Name = "Searchcard4";
            this.Searchcard4.Size = new System.Drawing.Size(158, 251);
            this.Searchcard4.TabIndex = 14;
            this.Searchcard4.Text = "Searchcard4";
            this.Searchcard4.UseVisualStyleBackColor = true;
            this.Searchcard4.Visible = false;
            this.Searchcard4.Click += new System.EventHandler(this.Searchcard4_Click);
            // 
            // SearchBack
            // 
            this.SearchBack.Location = new System.Drawing.Point(20, 194);
            this.SearchBack.Name = "SearchBack";
            this.SearchBack.Size = new System.Drawing.Size(38, 37);
            this.SearchBack.TabIndex = 16;
            this.SearchBack.Text = "<";
            this.SearchBack.UseVisualStyleBackColor = true;
            this.SearchBack.Visible = false;
            this.SearchBack.Click += new System.EventHandler(this.SearchBack_Click);
            // 
            // SearchForward
            // 
            this.SearchForward.Location = new System.Drawing.Point(720, 194);
            this.SearchForward.Name = "SearchForward";
            this.SearchForward.Size = new System.Drawing.Size(38, 37);
            this.SearchForward.TabIndex = 17;
            this.SearchForward.Text = ">";
            this.SearchForward.UseVisualStyleBackColor = true;
            this.SearchForward.Visible = false;
            this.SearchForward.Click += new System.EventHandler(this.SearchForward_Click);
            // 
            // SwitchCard4
            // 
            this.SwitchCard4.Location = new System.Drawing.Point(556, 87);
            this.SwitchCard4.Name = "SwitchCard4";
            this.SwitchCard4.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard4.TabIndex = 23;
            this.SwitchCard4.Text = "button4";
            this.SwitchCard4.UseVisualStyleBackColor = true;
            this.SwitchCard4.Visible = false;
            this.SwitchCard4.Click += new System.EventHandler(this.SwitchCard4_Click);
            // 
            // SwitchCard3
            // 
            this.SwitchCard3.Location = new System.Drawing.Point(392, 87);
            this.SwitchCard3.Name = "SwitchCard3";
            this.SwitchCard3.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard3.TabIndex = 22;
            this.SwitchCard3.Text = "button3";
            this.SwitchCard3.UseVisualStyleBackColor = true;
            this.SwitchCard3.Visible = false;
            this.SwitchCard3.Click += new System.EventHandler(this.SwitchCard3_Click);
            // 
            // SwitchCard2
            // 
            this.SwitchCard2.Location = new System.Drawing.Point(228, 87);
            this.SwitchCard2.Name = "SwitchCard2";
            this.SwitchCard2.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard2.TabIndex = 21;
            this.SwitchCard2.Text = "button2";
            this.SwitchCard2.UseVisualStyleBackColor = true;
            this.SwitchCard2.Visible = false;
            this.SwitchCard2.Click += new System.EventHandler(this.SwitchCard2_Click);
            // 
            // SwitchCard1
            // 
            this.SwitchCard1.Location = new System.Drawing.Point(64, 87);
            this.SwitchCard1.Name = "SwitchCard1";
            this.SwitchCard1.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard1.TabIndex = 20;
            this.SwitchCard1.Text = "button1";
            this.SwitchCard1.UseVisualStyleBackColor = true;
            this.SwitchCard1.Visible = false;
            this.SwitchCard1.Click += new System.EventHandler(this.SwitchCard1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(615, 34);
            this.label1.TabIndex = 24;
            this.label1.Text = "Pick 2 Cards In Your Hand That you want to switch";
            this.label1.Visible = false;
            // 
            // PickCardFromHand1
            // 
            this.PickCardFromHand1.Location = new System.Drawing.Point(77, 47);
            this.PickCardFromHand1.Name = "PickCardFromHand1";
            this.PickCardFromHand1.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand1.TabIndex = 30;
            this.PickCardFromHand1.Text = "button3";
            this.PickCardFromHand1.UseVisualStyleBackColor = true;
            this.PickCardFromHand1.Visible = false;
            this.PickCardFromHand1.Click += new System.EventHandler(this.PickCardFromHand1_Click);
            // 
            // PickCardFromHand2
            // 
            this.PickCardFromHand2.Location = new System.Drawing.Point(239, 47);
            this.PickCardFromHand2.Name = "PickCardFromHand2";
            this.PickCardFromHand2.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand2.TabIndex = 31;
            this.PickCardFromHand2.Text = "button1";
            this.PickCardFromHand2.UseVisualStyleBackColor = true;
            this.PickCardFromHand2.Visible = false;
            this.PickCardFromHand2.Click += new System.EventHandler(this.PickCardFromHand2_Click);
            // 
            // PickCardFromHand3
            // 
            this.PickCardFromHand3.Location = new System.Drawing.Point(390, 47);
            this.PickCardFromHand3.Name = "PickCardFromHand3";
            this.PickCardFromHand3.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand3.TabIndex = 32;
            this.PickCardFromHand3.Text = "button2";
            this.PickCardFromHand3.UseVisualStyleBackColor = true;
            this.PickCardFromHand3.Visible = false;
            this.PickCardFromHand3.Click += new System.EventHandler(this.PickCardFromHand3_Click);
            // 
            // PickCardFromHand4
            // 
            this.PickCardFromHand4.Location = new System.Drawing.Point(541, 46);
            this.PickCardFromHand4.Name = "PickCardFromHand4";
            this.PickCardFromHand4.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand4.TabIndex = 33;
            this.PickCardFromHand4.Text = "button4";
            this.PickCardFromHand4.UseVisualStyleBackColor = true;
            this.PickCardFromHand4.Visible = false;
            this.PickCardFromHand4.Click += new System.EventHandler(this.PickCardFromHand4_Click);
            // 
            // ThereCard5
            // 
            this.ThereCard5.Location = new System.Drawing.Point(471, -2);
            this.ThereCard5.Name = "ThereCard5";
            this.ThereCard5.Size = new System.Drawing.Size(100, 141);
            this.ThereCard5.TabIndex = 38;
            this.ThereCard5.Text = "button1";
            this.ThereCard5.UseVisualStyleBackColor = true;
            this.ThereCard5.Visible = false;
            // 
            // ThereCard4
            // 
            this.ThereCard4.Location = new System.Drawing.Point(365, -2);
            this.ThereCard4.Name = "ThereCard4";
            this.ThereCard4.Size = new System.Drawing.Size(100, 141);
            this.ThereCard4.TabIndex = 37;
            this.ThereCard4.Text = "button1";
            this.ThereCard4.UseVisualStyleBackColor = true;
            this.ThereCard4.Visible = false;
            // 
            // ThereCard3
            // 
            this.ThereCard3.Location = new System.Drawing.Point(259, -2);
            this.ThereCard3.Name = "ThereCard3";
            this.ThereCard3.Size = new System.Drawing.Size(100, 141);
            this.ThereCard3.TabIndex = 36;
            this.ThereCard3.Text = "button1";
            this.ThereCard3.UseVisualStyleBackColor = true;
            this.ThereCard3.Visible = false;
            // 
            // ThereCard2
            // 
            this.ThereCard2.Location = new System.Drawing.Point(153, -2);
            this.ThereCard2.Name = "ThereCard2";
            this.ThereCard2.Size = new System.Drawing.Size(100, 141);
            this.ThereCard2.TabIndex = 35;
            this.ThereCard2.Text = "button1";
            this.ThereCard2.UseVisualStyleBackColor = true;
            this.ThereCard2.Visible = false;
            // 
            // ThereCard1
            // 
            this.ThereCard1.Location = new System.Drawing.Point(47, -2);
            this.ThereCard1.Name = "ThereCard1";
            this.ThereCard1.Size = new System.Drawing.Size(100, 141);
            this.ThereCard1.TabIndex = 34;
            this.ThereCard1.Text = "button1";
            this.ThereCard1.UseVisualStyleBackColor = true;
            this.ThereCard1.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 450);
            this.Controls.Add(this.ThereCard5);
            this.Controls.Add(this.ThereCard4);
            this.Controls.Add(this.ThereCard3);
            this.Controls.Add(this.ThereCard2);
            this.Controls.Add(this.ThereCard1);
            this.Controls.Add(this.PickCardFromHand4);
            this.Controls.Add(this.PickCardFromHand3);
            this.Controls.Add(this.PickCardFromHand2);
            this.Controls.Add(this.PickCardFromHand1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SwitchCard4);
            this.Controls.Add(this.SwitchCard3);
            this.Controls.Add(this.SwitchCard2);
            this.Controls.Add(this.SwitchCard1);
            this.Controls.Add(this.SearchForward);
            this.Controls.Add(this.SearchBack);
            this.Controls.Add(this.Searchcard4);
            this.Controls.Add(this.Searchcard3);
            this.Controls.Add(this.Searchcard2);
            this.Controls.Add(this.Searchcard1);
            this.Controls.Add(this.Deck);
            this.Controls.Add(this.YourCard5);
            this.Controls.Add(this.YourCard4);
            this.Controls.Add(this.YourCard3);
            this.Controls.Add(this.YourCard2);
            this.Controls.Add(this.YourCard1);
            this.Controls.Add(this.NumberOfCardsInYourDeckLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label NumberOfCardsInYourDeckLabel;
        private System.Windows.Forms.Button YourCard1;
        private System.Windows.Forms.Button YourCard2;
        private System.Windows.Forms.Button YourCard3;
        private System.Windows.Forms.Button YourCard4;
        private System.Windows.Forms.Button YourCard5;
        private System.Windows.Forms.Button Deck;
        private System.Windows.Forms.Button Searchcard1;
        private System.Windows.Forms.Button Searchcard2;
        private System.Windows.Forms.Button Searchcard3;
        private System.Windows.Forms.Button Searchcard4;
        private System.Windows.Forms.Button SearchBack;
        private System.Windows.Forms.Button SearchForward;
        private System.Windows.Forms.Button SwitchCard4;
        private System.Windows.Forms.Button SwitchCard3;
        private System.Windows.Forms.Button SwitchCard2;
        private System.Windows.Forms.Button SwitchCard1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button PickCardFromHand1;
        private System.Windows.Forms.Button PickCardFromHand2;
        private System.Windows.Forms.Button PickCardFromHand3;
        private System.Windows.Forms.Button PickCardFromHand4;
        private System.Windows.Forms.Button ThereCard5;
        private System.Windows.Forms.Button ThereCard4;
        private System.Windows.Forms.Button ThereCard3;
        private System.Windows.Forms.Button ThereCard2;
        private System.Windows.Forms.Button ThereCard1;
    }
}

