﻿
namespace Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.NumberOfCardsInYourDeckLabel = new System.Windows.Forms.Label();
            this.YourCard1 = new System.Windows.Forms.Button();
            this.YourCard2 = new System.Windows.Forms.Button();
            this.YourCard3 = new System.Windows.Forms.Button();
            this.YourCard4 = new System.Windows.Forms.Button();
            this.YourCard5 = new System.Windows.Forms.Button();
            this.Deck = new System.Windows.Forms.Button();
            this.Searchcard1 = new System.Windows.Forms.Button();
            this.Searchcard2 = new System.Windows.Forms.Button();
            this.Searchcard3 = new System.Windows.Forms.Button();
            this.Searchcard4 = new System.Windows.Forms.Button();
            this.SearchBack = new System.Windows.Forms.Button();
            this.SearchForward = new System.Windows.Forms.Button();
            this.SwitchCard4 = new System.Windows.Forms.Button();
            this.SwitchCard3 = new System.Windows.Forms.Button();
            this.SwitchCard2 = new System.Windows.Forms.Button();
            this.SwitchCard1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.PickCardFromHand1 = new System.Windows.Forms.Button();
            this.PickCardFromHand2 = new System.Windows.Forms.Button();
            this.PickCardFromHand3 = new System.Windows.Forms.Button();
            this.PickCardFromHand4 = new System.Windows.Forms.Button();
            this.UPButton = new System.Windows.Forms.Button();
            this.A1 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.DownButton = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NumberOfCardsInYourDeckLabel
            // 
            this.NumberOfCardsInYourDeckLabel.AutoSize = true;
            this.NumberOfCardsInYourDeckLabel.Location = new System.Drawing.Point(653, 281);
            this.NumberOfCardsInYourDeckLabel.Name = "NumberOfCardsInYourDeckLabel";
            this.NumberOfCardsInYourDeckLabel.Size = new System.Drawing.Size(33, 13);
            this.NumberOfCardsInYourDeckLabel.TabIndex = 4;
            this.NumberOfCardsInYourDeckLabel.Text = "Deck";
            // 
            // YourCard1
            // 
            this.YourCard1.Location = new System.Drawing.Point(47, 297);
            this.YourCard1.Name = "YourCard1";
            this.YourCard1.Size = new System.Drawing.Size(100, 141);
            this.YourCard1.TabIndex = 5;
            this.YourCard1.Text = "button1";
            this.YourCard1.UseVisualStyleBackColor = true;
            this.YourCard1.Click += new System.EventHandler(this.YourCard1_Click);
            // 
            // YourCard2
            // 
            this.YourCard2.Location = new System.Drawing.Point(153, 297);
            this.YourCard2.Name = "YourCard2";
            this.YourCard2.Size = new System.Drawing.Size(100, 141);
            this.YourCard2.TabIndex = 6;
            this.YourCard2.Text = "button1";
            this.YourCard2.UseVisualStyleBackColor = true;
            this.YourCard2.Click += new System.EventHandler(this.button2_Click);
            // 
            // YourCard3
            // 
            this.YourCard3.Location = new System.Drawing.Point(259, 297);
            this.YourCard3.Name = "YourCard3";
            this.YourCard3.Size = new System.Drawing.Size(100, 141);
            this.YourCard3.TabIndex = 7;
            this.YourCard3.Text = "button1";
            this.YourCard3.UseVisualStyleBackColor = true;
            this.YourCard3.Click += new System.EventHandler(this.button1_Click);
            // 
            // YourCard4
            // 
            this.YourCard4.Location = new System.Drawing.Point(365, 297);
            this.YourCard4.Name = "YourCard4";
            this.YourCard4.Size = new System.Drawing.Size(100, 141);
            this.YourCard4.TabIndex = 8;
            this.YourCard4.Text = "button1";
            this.YourCard4.UseVisualStyleBackColor = true;
            this.YourCard4.Click += new System.EventHandler(this.button3_Click);
            // 
            // YourCard5
            // 
            this.YourCard5.Location = new System.Drawing.Point(471, 297);
            this.YourCard5.Name = "YourCard5";
            this.YourCard5.Size = new System.Drawing.Size(100, 141);
            this.YourCard5.TabIndex = 9;
            this.YourCard5.Text = "button1";
            this.YourCard5.UseVisualStyleBackColor = true;
            this.YourCard5.Click += new System.EventHandler(this.button4_Click);
            // 
            // Deck
            // 
            this.Deck.Location = new System.Drawing.Point(656, 297);
            this.Deck.Name = "Deck";
            this.Deck.Size = new System.Drawing.Size(100, 141);
            this.Deck.TabIndex = 10;
            this.Deck.Text = "button1";
            this.Deck.UseVisualStyleBackColor = true;
            // 
            // Searchcard1
            // 
            this.Searchcard1.Location = new System.Drawing.Point(64, 87);
            this.Searchcard1.Name = "Searchcard1";
            this.Searchcard1.Size = new System.Drawing.Size(158, 251);
            this.Searchcard1.TabIndex = 11;
            this.Searchcard1.Text = "Searchcard1";
            this.Searchcard1.UseVisualStyleBackColor = true;
            this.Searchcard1.Visible = false;
            this.Searchcard1.Click += new System.EventHandler(this.Searchcard1_Click);
            // 
            // Searchcard2
            // 
            this.Searchcard2.Location = new System.Drawing.Point(228, 87);
            this.Searchcard2.Name = "Searchcard2";
            this.Searchcard2.Size = new System.Drawing.Size(158, 251);
            this.Searchcard2.TabIndex = 12;
            this.Searchcard2.Text = "Searchcard2";
            this.Searchcard2.UseVisualStyleBackColor = true;
            this.Searchcard2.Visible = false;
            this.Searchcard2.Click += new System.EventHandler(this.Searchcard2_Click);
            // 
            // Searchcard3
            // 
            this.Searchcard3.Location = new System.Drawing.Point(392, 87);
            this.Searchcard3.Name = "Searchcard3";
            this.Searchcard3.Size = new System.Drawing.Size(158, 251);
            this.Searchcard3.TabIndex = 13;
            this.Searchcard3.Text = "Searchcard3";
            this.Searchcard3.UseVisualStyleBackColor = true;
            this.Searchcard3.Visible = false;
            this.Searchcard3.Click += new System.EventHandler(this.Searchcard3_Click);
            // 
            // Searchcard4
            // 
            this.Searchcard4.Location = new System.Drawing.Point(556, 87);
            this.Searchcard4.Name = "Searchcard4";
            this.Searchcard4.Size = new System.Drawing.Size(158, 251);
            this.Searchcard4.TabIndex = 14;
            this.Searchcard4.Text = "Searchcard4";
            this.Searchcard4.UseVisualStyleBackColor = true;
            this.Searchcard4.Visible = false;
            this.Searchcard4.Click += new System.EventHandler(this.Searchcard4_Click);
            // 
            // SearchBack
            // 
            this.SearchBack.Location = new System.Drawing.Point(20, 194);
            this.SearchBack.Name = "SearchBack";
            this.SearchBack.Size = new System.Drawing.Size(38, 37);
            this.SearchBack.TabIndex = 16;
            this.SearchBack.Text = "<";
            this.SearchBack.UseVisualStyleBackColor = true;
            this.SearchBack.Visible = false;
            this.SearchBack.Click += new System.EventHandler(this.SearchBack_Click);
            // 
            // SearchForward
            // 
            this.SearchForward.Location = new System.Drawing.Point(720, 194);
            this.SearchForward.Name = "SearchForward";
            this.SearchForward.Size = new System.Drawing.Size(38, 37);
            this.SearchForward.TabIndex = 17;
            this.SearchForward.Text = ">";
            this.SearchForward.UseVisualStyleBackColor = true;
            this.SearchForward.Visible = false;
            this.SearchForward.Click += new System.EventHandler(this.SearchForward_Click);
            // 
            // SwitchCard4
            // 
            this.SwitchCard4.Location = new System.Drawing.Point(556, 87);
            this.SwitchCard4.Name = "SwitchCard4";
            this.SwitchCard4.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard4.TabIndex = 23;
            this.SwitchCard4.Text = "button4";
            this.SwitchCard4.UseVisualStyleBackColor = true;
            this.SwitchCard4.Visible = false;
            this.SwitchCard4.Click += new System.EventHandler(this.SwitchCard4_Click);
            // 
            // SwitchCard3
            // 
            this.SwitchCard3.Location = new System.Drawing.Point(392, 87);
            this.SwitchCard3.Name = "SwitchCard3";
            this.SwitchCard3.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard3.TabIndex = 22;
            this.SwitchCard3.Text = "button3";
            this.SwitchCard3.UseVisualStyleBackColor = true;
            this.SwitchCard3.Visible = false;
            this.SwitchCard3.Click += new System.EventHandler(this.SwitchCard3_Click);
            // 
            // SwitchCard2
            // 
            this.SwitchCard2.Location = new System.Drawing.Point(228, 87);
            this.SwitchCard2.Name = "SwitchCard2";
            this.SwitchCard2.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard2.TabIndex = 21;
            this.SwitchCard2.Text = "button2";
            this.SwitchCard2.UseVisualStyleBackColor = true;
            this.SwitchCard2.Visible = false;
            this.SwitchCard2.Click += new System.EventHandler(this.SwitchCard2_Click);
            // 
            // SwitchCard1
            // 
            this.SwitchCard1.Location = new System.Drawing.Point(64, 87);
            this.SwitchCard1.Name = "SwitchCard1";
            this.SwitchCard1.Size = new System.Drawing.Size(158, 251);
            this.SwitchCard1.TabIndex = 20;
            this.SwitchCard1.Text = "button1";
            this.SwitchCard1.UseVisualStyleBackColor = true;
            this.SwitchCard1.Visible = false;
            this.SwitchCard1.Click += new System.EventHandler(this.SwitchCard1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Franklin Gothic Demi", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(615, 34);
            this.label1.TabIndex = 24;
            this.label1.Text = "Pick 2 Cards In Your Hand That you want to switch";
            this.label1.Visible = false;
            // 
            // PickCardFromHand1
            // 
            this.PickCardFromHand1.Location = new System.Drawing.Point(77, 47);
            this.PickCardFromHand1.Name = "PickCardFromHand1";
            this.PickCardFromHand1.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand1.TabIndex = 30;
            this.PickCardFromHand1.Text = "button3";
            this.PickCardFromHand1.UseVisualStyleBackColor = true;
            this.PickCardFromHand1.Visible = false;
            this.PickCardFromHand1.Click += new System.EventHandler(this.PickCardFromHand1_Click);
            // 
            // PickCardFromHand2
            // 
            this.PickCardFromHand2.Location = new System.Drawing.Point(239, 47);
            this.PickCardFromHand2.Name = "PickCardFromHand2";
            this.PickCardFromHand2.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand2.TabIndex = 31;
            this.PickCardFromHand2.Text = "button1";
            this.PickCardFromHand2.UseVisualStyleBackColor = true;
            this.PickCardFromHand2.Visible = false;
            this.PickCardFromHand2.Click += new System.EventHandler(this.PickCardFromHand2_Click);
            // 
            // PickCardFromHand3
            // 
            this.PickCardFromHand3.Location = new System.Drawing.Point(390, 47);
            this.PickCardFromHand3.Name = "PickCardFromHand3";
            this.PickCardFromHand3.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand3.TabIndex = 32;
            this.PickCardFromHand3.Text = "button2";
            this.PickCardFromHand3.UseVisualStyleBackColor = true;
            this.PickCardFromHand3.Visible = false;
            this.PickCardFromHand3.Click += new System.EventHandler(this.PickCardFromHand3_Click);
            // 
            // PickCardFromHand4
            // 
            this.PickCardFromHand4.Location = new System.Drawing.Point(541, 46);
            this.PickCardFromHand4.Name = "PickCardFromHand4";
            this.PickCardFromHand4.Size = new System.Drawing.Size(145, 206);
            this.PickCardFromHand4.TabIndex = 33;
            this.PickCardFromHand4.Text = "button4";
            this.PickCardFromHand4.UseVisualStyleBackColor = true;
            this.PickCardFromHand4.Visible = false;
            this.PickCardFromHand4.Click += new System.EventHandler(this.PickCardFromHand4_Click);
            // 
            // UPButton
            // 
            this.UPButton.Location = new System.Drawing.Point(700, 9);
            this.UPButton.Name = "UPButton";
            this.UPButton.Size = new System.Drawing.Size(58, 63);
            this.UPButton.TabIndex = 34;
            this.UPButton.Text = "/\\";
            this.UPButton.UseVisualStyleBackColor = true;
            this.UPButton.Click += new System.EventHandler(this.UPButton_Click);
            // 
            // A1
            // 
            this.A1.Location = new System.Drawing.Point(44, 18);
            this.A1.Name = "A1";
            this.A1.Size = new System.Drawing.Size(59, 54);
            this.A1.TabIndex = 36;
            this.A1.UseVisualStyleBackColor = true;
            this.A1.Visible = false;
            this.A1.Click += new System.EventHandler(this.A1_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(174, 18);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(59, 54);
            this.button3.TabIndex = 38;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(239, 18);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(59, 54);
            this.button4.TabIndex = 39;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click_1);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(432, 18);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(59, 54);
            this.button5.TabIndex = 42;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Visible = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(367, 18);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(59, 54);
            this.button6.TabIndex = 41;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Visible = false;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(302, 18);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(59, 54);
            this.button7.TabIndex = 40;
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Visible = false;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(630, 18);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(59, 54);
            this.button8.TabIndex = 45;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Visible = false;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button9.Location = new System.Drawing.Point(565, 18);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(59, 54);
            this.button9.TabIndex = 44;
            this.button9.Text = "3";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Visible = false;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(630, 78);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(59, 54);
            this.button10.TabIndex = 55;
            this.button10.Text = "  ";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Visible = false;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(565, 78);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(59, 54);
            this.button11.TabIndex = 54;
            this.button11.Text = "  ";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Visible = false;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(497, 78);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(59, 54);
            this.button12.TabIndex = 53;
            this.button12.Text = "  ";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Visible = false;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(432, 78);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(59, 54);
            this.button13.TabIndex = 52;
            this.button13.Text = "  ";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Visible = false;
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(367, 78);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(59, 54);
            this.button14.TabIndex = 51;
            this.button14.Text = "  ";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Visible = false;
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(302, 78);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(59, 54);
            this.button15.TabIndex = 50;
            this.button15.Text = "  ";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Visible = false;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(239, 78);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(59, 54);
            this.button16.TabIndex = 49;
            this.button16.Text = "  ";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Visible = false;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(174, 78);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(59, 54);
            this.button17.TabIndex = 48;
            this.button17.Text = "  ";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Visible = false;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(109, 78);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(59, 54);
            this.button18.TabIndex = 47;
            this.button18.Text = "  ";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Visible = false;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(44, 78);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(59, 54);
            this.button19.TabIndex = 46;
            this.button19.Text = "  ";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Visible = false;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(630, 138);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(59, 54);
            this.button20.TabIndex = 65;
            this.button20.Text = "  ";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Visible = false;
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(565, 138);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(59, 54);
            this.button21.TabIndex = 64;
            this.button21.Text = "  ";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Visible = false;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(497, 138);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(59, 54);
            this.button22.TabIndex = 63;
            this.button22.Text = "  ";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Visible = false;
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(432, 138);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(59, 54);
            this.button23.TabIndex = 62;
            this.button23.Text = "  ";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Visible = false;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(367, 138);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(59, 54);
            this.button24.TabIndex = 61;
            this.button24.Text = "  ";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Visible = false;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(302, 138);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(59, 54);
            this.button25.TabIndex = 60;
            this.button25.Text = "  ";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Visible = false;
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(239, 138);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(59, 54);
            this.button26.TabIndex = 59;
            this.button26.Text = "  ";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Visible = false;
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(174, 138);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(59, 54);
            this.button27.TabIndex = 58;
            this.button27.Text = "  ";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Visible = false;
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(109, 138);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(59, 54);
            this.button28.TabIndex = 57;
            this.button28.Text = "  ";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Visible = false;
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(44, 138);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(59, 54);
            this.button29.TabIndex = 56;
            this.button29.Text = "  ";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Visible = false;
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(630, 198);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(59, 54);
            this.button30.TabIndex = 75;
            this.button30.Text = "  ";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Visible = false;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(565, 198);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(59, 54);
            this.button31.TabIndex = 74;
            this.button31.Text = "  ";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Visible = false;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(497, 198);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(59, 54);
            this.button32.TabIndex = 73;
            this.button32.Text = "  ";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Visible = false;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(432, 198);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(59, 54);
            this.button33.TabIndex = 72;
            this.button33.Text = "  ";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Visible = false;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(367, 198);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(59, 54);
            this.button34.TabIndex = 71;
            this.button34.Text = "  ";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Visible = false;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(302, 198);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(59, 54);
            this.button35.TabIndex = 70;
            this.button35.Text = "  ";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Visible = false;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(239, 198);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(59, 54);
            this.button36.TabIndex = 69;
            this.button36.Text = "  ";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Visible = false;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(174, 198);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(59, 54);
            this.button37.TabIndex = 68;
            this.button37.Text = "  ";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Visible = false;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(109, 198);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(59, 54);
            this.button38.TabIndex = 67;
            this.button38.Text = "  ";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Visible = false;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(44, 198);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(59, 54);
            this.button39.TabIndex = 66;
            this.button39.Text = "  ";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Visible = false;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(632, 258);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(59, 54);
            this.button40.TabIndex = 85;
            this.button40.Text = "  ";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Visible = false;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(567, 258);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(59, 54);
            this.button41.TabIndex = 84;
            this.button41.Text = "  ";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Visible = false;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(499, 258);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(59, 54);
            this.button42.TabIndex = 83;
            this.button42.Text = "  ";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Visible = false;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(434, 258);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(59, 54);
            this.button43.TabIndex = 82;
            this.button43.Text = "  ";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Visible = false;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(369, 258);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(59, 54);
            this.button44.TabIndex = 81;
            this.button44.Text = "  ";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Visible = false;
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(304, 258);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(59, 54);
            this.button45.TabIndex = 80;
            this.button45.Text = "  ";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Visible = false;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(241, 258);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(59, 54);
            this.button46.TabIndex = 79;
            this.button46.Text = "  ";
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Visible = false;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(176, 258);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(59, 54);
            this.button47.TabIndex = 78;
            this.button47.Text = "  ";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Visible = false;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(111, 258);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(59, 54);
            this.button48.TabIndex = 77;
            this.button48.Text = "  ";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Visible = false;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(46, 258);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(59, 54);
            this.button49.TabIndex = 76;
            this.button49.Text = "  ";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Visible = false;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(632, 318);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(59, 54);
            this.button50.TabIndex = 95;
            this.button50.Text = "  ";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Visible = false;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(567, 318);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(59, 54);
            this.button51.TabIndex = 94;
            this.button51.Text = "  ";
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Visible = false;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(499, 318);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(59, 54);
            this.button52.TabIndex = 93;
            this.button52.Text = "  ";
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Visible = false;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(434, 318);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(59, 54);
            this.button53.TabIndex = 92;
            this.button53.Text = "  ";
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Visible = false;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(369, 318);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(59, 54);
            this.button54.TabIndex = 91;
            this.button54.Text = "  ";
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Visible = false;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(304, 318);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(59, 54);
            this.button55.TabIndex = 90;
            this.button55.Text = "  ";
            this.button55.UseVisualStyleBackColor = true;
            this.button55.Visible = false;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(241, 318);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(59, 54);
            this.button56.TabIndex = 89;
            this.button56.Text = "  ";
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Visible = false;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(176, 318);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(59, 54);
            this.button57.TabIndex = 88;
            this.button57.Text = "  ";
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Visible = false;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(111, 318);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(59, 54);
            this.button58.TabIndex = 87;
            this.button58.Text = "  ";
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Visible = false;
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(46, 318);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(59, 54);
            this.button59.TabIndex = 86;
            this.button59.Text = "  ";
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Visible = false;
            // 
            // button60
            // 
            this.button60.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button60.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button60.Location = new System.Drawing.Point(632, 378);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(59, 54);
            this.button60.TabIndex = 105;
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Visible = false;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button61.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button61.Location = new System.Drawing.Point(567, 378);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(59, 54);
            this.button61.TabIndex = 104;
            this.button61.Text = "3";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Visible = false;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button63
            // 
            this.button63.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button63.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button63.Location = new System.Drawing.Point(434, 378);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(59, 54);
            this.button63.TabIndex = 102;
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Visible = false;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button64
            // 
            this.button64.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button64.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button64.Location = new System.Drawing.Point(369, 378);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(59, 54);
            this.button64.TabIndex = 101;
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Visible = false;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button65
            // 
            this.button65.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button65.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button65.Location = new System.Drawing.Point(304, 378);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(59, 54);
            this.button65.TabIndex = 100;
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Visible = false;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button66
            // 
            this.button66.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button66.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button66.Location = new System.Drawing.Point(241, 378);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(59, 54);
            this.button66.TabIndex = 99;
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Visible = false;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // button67
            // 
            this.button67.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button67.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button67.Location = new System.Drawing.Point(176, 378);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(59, 54);
            this.button67.TabIndex = 98;
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Visible = false;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button69
            // 
            this.button69.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button69.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button69.Location = new System.Drawing.Point(46, 378);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(59, 54);
            this.button69.TabIndex = 96;
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Visible = false;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // DownButton
            // 
            this.DownButton.Location = new System.Drawing.Point(700, 375);
            this.DownButton.Name = "DownButton";
            this.DownButton.Size = new System.Drawing.Size(58, 63);
            this.DownButton.TabIndex = 106;
            this.DownButton.Text = "\\/";
            this.DownButton.UseVisualStyleBackColor = true;
            this.DownButton.Visible = false;
            this.DownButton.Click += new System.EventHandler(this.DownButton_Click);
            // 
            // button62
            // 
            this.button62.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button62.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button62.Location = new System.Drawing.Point(499, 378);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(59, 54);
            this.button62.TabIndex = 103;
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Visible = false;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button68
            // 
            this.button68.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button68.ForeColor = System.Drawing.Color.MidnightBlue;
            this.button68.Location = new System.Drawing.Point(111, 378);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(59, 54);
            this.button68.TabIndex = 97;
            this.button68.Text = "3";
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Visible = false;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(497, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(59, 54);
            this.button1.TabIndex = 43;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Visible = false;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft YaHei", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.button2.Location = new System.Drawing.Point(109, 18);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(59, 54);
            this.button2.TabIndex = 37;
            this.button2.Text = "3";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(768, 450);
            this.Controls.Add(this.DownButton);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.A1);
            this.Controls.Add(this.UPButton);
            this.Controls.Add(this.PickCardFromHand4);
            this.Controls.Add(this.PickCardFromHand3);
            this.Controls.Add(this.PickCardFromHand2);
            this.Controls.Add(this.PickCardFromHand1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SwitchCard4);
            this.Controls.Add(this.SwitchCard3);
            this.Controls.Add(this.SwitchCard2);
            this.Controls.Add(this.SwitchCard1);
            this.Controls.Add(this.SearchForward);
            this.Controls.Add(this.SearchBack);
            this.Controls.Add(this.Searchcard4);
            this.Controls.Add(this.Searchcard3);
            this.Controls.Add(this.Searchcard2);
            this.Controls.Add(this.Searchcard1);
            this.Controls.Add(this.Deck);
            this.Controls.Add(this.YourCard5);
            this.Controls.Add(this.YourCard4);
            this.Controls.Add(this.YourCard3);
            this.Controls.Add(this.YourCard2);
            this.Controls.Add(this.YourCard1);
            this.Controls.Add(this.NumberOfCardsInYourDeckLabel);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label NumberOfCardsInYourDeckLabel;
        private System.Windows.Forms.Button YourCard1;
        private System.Windows.Forms.Button YourCard2;
        private System.Windows.Forms.Button YourCard3;
        private System.Windows.Forms.Button YourCard4;
        private System.Windows.Forms.Button YourCard5;
        private System.Windows.Forms.Button Deck;
        private System.Windows.Forms.Button Searchcard1;
        private System.Windows.Forms.Button Searchcard2;
        private System.Windows.Forms.Button Searchcard3;
        private System.Windows.Forms.Button Searchcard4;
        private System.Windows.Forms.Button SearchBack;
        private System.Windows.Forms.Button SearchForward;
        private System.Windows.Forms.Button SwitchCard4;
        private System.Windows.Forms.Button SwitchCard3;
        private System.Windows.Forms.Button SwitchCard2;
        private System.Windows.Forms.Button SwitchCard1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button PickCardFromHand1;
        private System.Windows.Forms.Button PickCardFromHand2;
        private System.Windows.Forms.Button PickCardFromHand3;
        private System.Windows.Forms.Button PickCardFromHand4;
        private System.Windows.Forms.Button UPButton;
        private System.Windows.Forms.Button A1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button DownButton;
    }
}

